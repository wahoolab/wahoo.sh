

cd bin || exit 1
./wahoo.sh setup



